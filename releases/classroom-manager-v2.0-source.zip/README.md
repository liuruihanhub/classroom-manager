# 教师课堂管理系统 v2.0

这是一个本地优先的教师课堂管理 PWA，并可选启用“同一教师账号、多设备实时同步”。2.0 增加课堂工作台、数据健康与云历史恢复、首次/升级引导，以及当前学期学生快速查找。未配置云端变量时直接进入本地模式；配置 Supabase 后才显示教师账号登录。项目不提供学生端、教师间共享、自动合并或云端业务后台。

面向教师的完整操作说明见：[《使用与维护手册》](使用与维护手册.md)。Supabase 建项、SQL、安全检查和回滚细节见：[SUPABASE_SETUP.md](SUPABASE_SETUP.md)。2.0 各阶段覆盖矩阵见：[V2_ITERATION_REPORT.md](V2_ITERATION_REPORT.md)；v1.2.5 回滚基线仍保留在 [V1_2_5_COVERAGE.md](V1_2_5_COVERAGE.md)。

## 两个独立交付物

- 主系统源码：`src/`；生产构建：`dist/`
- 独立随机抽名成品：`deliverables/独立随机抽名.html`
- 虚构验收数据：`tests/fixtures/v11-fictional-dataset.json`
- 测试报告：`TEST_REPORT.md`
- 需求映射：`REQUIREMENTS_MAPPING.md`
- 2.0 逐轮矩阵：`V2_ITERATION_REPORT.md`
- v1.2.5、2.0-rc1 与 2.0 回滚包：`releases/`
- 数据库迁移：`supabase/migrations/20260811_teacher_database_sync.sql`、`20260812_v2_payload.sql`

独立抽名页是单一 HTML 文件，完全离线、无账号、无 Supabase 配置、无网络请求，也不读取主系统存储。两套系统只在教师主动选择 JSON 文件时发生显式名单桥接。

## 环境与命令

- Node.js：`>=22.13.0`
- 安装依赖：`npm ci`
- 本地开发：`npm run dev`
- 生成虚构数据：`npm run fixture`
- 构建全部交付物：`npm run build`
- 核心与安全测试：`npm test`
- 构建加全量测试：`npm run test:all`
- 依赖漏洞检查：`npm audit`

`npm run build` 会生成 180/192/512 PNG 图标、打包独立单页、构建主系统，并把当前 `dist/assets` 中全部必要的非 source-map JS/CSS 写入 Service Worker 预缓存清单。Excel、PDF 和 Supabase 模块仍按需执行；未配置云端时不会加载 Supabase SDK。

## 本机打开

开发时运行 `npm run dev`，打开终端显示的地址。生产构建可用任意静态 HTTP 服务打开 `dist/`，例如：

```powershell
python -m http.server 4175 --bind 127.0.0.1 --directory dist
```

再访问 `http://127.0.0.1:4175`。独立抽名页直接双击 `deliverables/独立随机抽名.html`，可通过 `file://` 使用，无需构建或网络。

## 两种运行模式

### 未配置云同步

- 不显示账号或密码页，打开后直接进入“总览”。
- 数据只写入当前浏览器 `localStorage`。
- Windows、iPhone、iPad 互不自动同步；用“数据健康与恢复 → 导出当前本机版本”人工迁移。
- 设备锁屏是本机访问保护。清理浏览器数据、卸载浏览器或设备损坏可能导致数据丢失。

### 已配置云同步

- 只接受 `VITE_SUPABASE_URL` 和 `VITE_SUPABASE_PUBLISHABLE_KEY`；不得向前端提供 `service_role`、数据库密码或访问令牌。
- 教师使用由 Supabase 项目管理员预先创建的 Email/Password 账号登录；系统不开放自助注册。
- 修改先原子写入当前账号的本机缓存，再以 revision CAS 上传整份有效 JSON。旧 revision 必须进入“同步冲突”，禁止静默覆盖。
- 断网可继续记录；100 次离线修改只保留并补传最终有效快照，不复制考勤或成绩记录。
- 本机缓存、安全副本和迁移标记都按 `user_id` 隔离。退出后立即清空页面数据；存在待同步或未处理决策时，必须先同步或导出本机 JSON。
- Realtime 只用于通知更高 revision。重复、乱序和自回声不会触发上传回环。

复制 `.env.example` 为 `.env.local` 后，只填写两项浏览器公开配置。仓库不会读取、记录或提交真实值。未配置或配置不完整时安全回退本地模式。

## 免费上线边界

推荐使用 Cloudflare Pages 发布 `dist/` 静态文件，Supabase Free 提供 Auth/Postgres/Realtime。Pages 没有 Worker、D1、服务端认证或业务 API 依赖。构建设置：

| 项目 | 值 |
| --- | --- |
| 根目录 | `classroom-manager` |
| 构建命令 | `npm ci && npm run build` |
| 输出目录 | `dist` |
| Node.js | 22.13.0 或更高兼容版本 |

必须先执行数据库迁移并完成真实双设备验收后，才能放入真实教学数据。本仓库只完成严格假服务和静态 SQL 安全验证，没有使用真实 Supabase 凭据，也不代表云端已经上线。

## 业务能力

- 课堂工作台一次保持“学期＋班级＋课程”上下文，可继续考勤、快速标记异常、抽名、记录课堂表现和查看预警；总览最近课堂两次主要点击内进入可编辑考勤。
- 数据健康与恢复集中显示同步状态、云端版本号、待同步快照、本机安全副本和最近 20 个云历史版本；历史恢复先导出、再双确认，并以 CAS 新建版本。
- 首次/大版本升级说明只在必要时出现；1.1/1.2 数据显式、幂等迁移到 2.0，失败不覆盖原数据。
- `Ctrl/Cmd+K` 或 `/` 打开当前使用中学期学生查找；同名按内部学生 ID 区分，多课程必须明确选择，跳转到准确考勤/成绩明细。
- 2 个以上学期、班级、课程、学期名单快照与课程挂载；姓名必填，学号可选且按文本保留前导零。
- 文本粘贴、CSV/Excel 预览校验、手动名单维护；有历史引用时阻止删除学生。
- 7 种考勤状态、按节记录、“其他”必填备注、一键全勤、异常筛选、阈值预警。
- 每个“学期＋班级＋课程”独立配置成绩项、权重、默认初始分和考勤自动计分规则；支持课堂表现事件修改与撤销。
- 主系统纯随机/加权随机抽名，默认纯随机；排除学生和课堂表现快捷记录。
- 单人、班级课程、跨班课程、异常预警报表；Excel、图像型 PDF、打印与 JSON 导出。
- JSON 整库恢复先做完整结构、唯一 ID、引用闭合、数值和考勤名单校验，再双重确认；失败不改原数据。
- 归档学期业务层只读；学期名单使用独立快照，新学期修改不会污染历史报表。

所有报表只提供分状态统计，不提供合并出勤指标。

## 数据、安全与 PWA

- 云端每名教师仅有一份 revisioned JSON 当前文档，成功覆盖前在同一事务写历史，至少保留最近 20 版。
- RLS 强制按 `auth.uid()` 隔离；CAS RPC 不接收 `owner_id`；服务端限制 payload 为 4 MiB 并检查基本版本结构，客户端仍执行完整 `validateDatabase`。
- Service Worker 只缓存同源静态应用资源，明确绕过 Supabase Auth、REST、RPC、Realtime、Storage 和 Functions 请求。
- PWA 更新不会强制接管正在使用的旧窗口。看到“新版本已下载”后，先确认数据已保存，再关闭所有本系统窗口并重新打开；最后一个旧窗口关闭后才激活新缓存并清理旧缓存。
- 2.0 静态产物额外保留冻结 v1.2.5 延迟加载可能请求的 5 个旧 hash 资源，用于一次性跨越旧缓存缺口；从 2.0 起所有必要 JS/CSS 都在安装时预缓存，后续等待期不依赖教师事先打开按需页。
- JSON、Excel、PDF 和截图可能含学生信息。应只保存在受保护设备，并遵守学校的数据授权、最小收集和删除规定。
- PWA 目标浏览器：当前 Chrome、Edge、iPhone/iPad Safari。iOS 安装必须通过可信 HTTPS 地址使用 Safari 的“添加到主屏幕”。

## 代码结构

- `src/core.mjs`：数据模型、完整校验、统计、成绩、随机算法和归档守卫
- `src/sync-core.mjs`：同步状态机、账号缓存、离线队列、CAS 与冲突处理
- `src/supabase-adapter.mjs`：Auth/Postgres RPC/Realtime 最小适配层
- `src/use-realtime-sync.jsx`：账号会话、首次迁移、数据应用与退出保护
- `src/main.jsx`：主页面、课堂业务入口与 2.0 更新提示
- `src/ClassroomWorkspace.jsx`：课堂工作台
- `src/DataHealth.jsx`：数据健康、云历史与安全恢复
- `src/StudentSearch.jsx`、`student-search-core.mjs`：当前学期学生查找与精确明细
- `src/Onboarding.jsx`：首次使用和数据边界说明
- `src/storage.js`：本地模式存储和 JSON 原子替换
- `standalone/`：独立抽名页源码与显式名单文件桥接
- `public/service-worker.js`：静态应用壳缓存与云 API 绕过
- `tests/`：v1.1/v1.2 回归、2.0 迁移/工作台/历史/搜索/RC、攻击样例、随机量化、同步与 SQL 安全测试

## 已知限制

- 首版同步整份 JSON，不做字段级自动合并；冲突必须人工选择一个版本。
- Supabase Free 可能休眠、限额或调整政策，且校园网络到海外服务的稳定性必须现场验证。云同步不是备份 SLA。
- 单份同步 payload 上限 4 MiB；长期大量历史数据应监控导出文件大小和同步耗时。
- PDF 是分页图像版，中文外观稳定但文字不可检索。
- iOS 可能在存储压力下清理网站数据；PWA 安装和云同步均不能替代定期 JSON 备份。
- 2.0 的全局查找只覆盖教师明确选择的使用中学期，不自动把同名学生跨学期合并为同一人。
- 独立单页的 Excel 能力已经内联，因此文件较大；极少数浏览器可能限制 `file://` 持久化，但当前打开会话仍可使用。
- 真实 Supabase 双设备、真实 Realtime 延迟、RLS 跨账号隔离及 Cloudflare 生产回滚仍必须由部署者用虚构账号完成上线验收。
