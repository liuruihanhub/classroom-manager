import { readFile, writeFile } from "node:fs/promises";

const dist = new URL("../dist/", import.meta.url);
const index = await readFile(new URL("index.html", dist), "utf8");
const entryAssets = [...index.matchAll(/(?:src|href)="(\.\/assets\/[^"?#]+\.(?:js|css))"/g)].map((match) => match[1]);
const assets = [...new Set(entryAssets)].sort().map((name) => `,"${name}"`).join("");
const workerUrl = new URL("service-worker.js", dist);
const worker = await readFile(workerUrl, "utf8");
if (!worker.includes("/*__PRECACHE_ASSETS__*/")) throw new Error("service worker 缺少预缓存占位符");
await writeFile(workerUrl, worker.replace("/*__PRECACHE_ASSETS__*/", assets), "utf8");
console.log(`PWA 预缓存已注入 ${assets ? assets.split(',').length - 1 : 0} 个构建资源`);
