# TEST_REPORT（v1.2.5 冻结基线）

测试日期：2026-08-12  
环境：Windows，Node.js v26.4.0，Chrome 151.0.7922.109，Vite 8.2.1  
测试数据：仅使用项目生成的虚构学生数据。

## 1. 命令与真实结果

```powershell
npm run test:all
npm audit --json
```

- 正式构建：通过。
- Node 测试：57 项通过，0 失败，0 跳过，0 TODO。
- `npm audit`：0 个已知漏洞（info/low/moderate/high/critical 均为 0）。
- 独立抽名成品：389,633 bytes；单一 HTML，无外链脚本或样式。
- 主入口：287.14 kB，gzip 88.65 kB；CSS 17.66/4.28 kB。
- 按需块：Supabase 117.46/31.61 kB、PDF 图像 199.57/46.84 kB、Excel 493.26/160.77 kB，均不进入未配置本地模式的首屏执行路径。
- PWA 构建：180/192/512 PNG 图标、manifest、Service Worker 与入口 JS/CSS 预缓存清单均生成成功。

### 必须保留的历史失败记录

v1.2.4 完成全站文案审校后的第一次 `npm run test:all`：构建通过，55/57；2 项失败均为测试仍断言旧界面文案，业务输出和数据断言未失败。随后只更新这 2 条断言以匹配新界面原词，再运行同一命令得到 57/57。该次失败没有被删除或表述为首次即通过。

浏览器工具也发生过两类环境失败：

1. `npx agent-browser` 初次使用系统 npm 缓存时因目录无写权限报 `EPERM`；改为项目临时缓存后 CLI 0.34.0 可运行。
2. agent-browser 自启动和连接调试端口均出现 `CDP response channel closed`/挂起；会话与进程已停止。最终改用系统 Chrome 151 加 DevTools Protocol 完成同一浏览器资料的升级、离线与截图，未用模拟结果冒充浏览器结果。

## 2. 固定虚构数据与业务量化

- 2 个学期，其中 1 个归档；每学期 6 个班，每班 60 人；当前学期 360 人，整库两学期名单快照共 720 人。
- 至少 2 门课程；固定样例含 13 张考勤表。
- 目标学生精确结果：缺勤 3 节、迟到 3 次、早退 3 次、病假 1 节、事假 1 节、其他 1 节。
- 预警：缺勤、迟到、早退三类各触发；病假和事假保持独立，不计入缺勤。
- 成绩：默认初始分 70；固定异常学生考勤分 43、加权总分 64.6；0、满分、负数、超上限、NaN/Infinity、事件修改/撤销均有边界测试。
- 归档：所有写入口由业务层拒绝；新学期名单使用独立学生 ID 和名单快照，修改不会污染历史报表。

## 3. JSON 与同步安全

- 完整 JSON 往返恢复成功。
- 错误版本、畸形 JSON、缺 settings、非法阈值/节数、重复顶层 ID、同班重复非空学号、悬空 offering/attendance/score/event/drawHistory 引用、考勤名单缺少/多余学生、非法成绩类型/权重/非有限数值全部拒绝。
- 任一校验失败返回原 `currentData` 引用；原子替换测试确认 localStorage 写入次数为 0。
- 100 次离线修改：本机每次立即保存，重连只上传 1 个最终有效快照。
- 100 次旧版本 CAS：100 次拒绝，静默覆盖 0 次。
- 100 份畸形远端 payload：100 份拒绝，本机最后有效副本不变。
- 重复、乱序和自回声 Realtime 不重复应用、不产生上传回环。
- 账号隔离、首次人工迁移、退出保护、云端意外为空冲突、安全副本最近 3 份均通过。
- SQL 静态检查确认：RLS 强制启用；RPC 使用 `auth.uid()` 且不接收 `owner_id`；浏览器角色不能直接写表；payload 上限 4 MiB；成功覆盖前同事务写历史；保留最近至少 20 版。

这些同步结果来自严格内存假服务和 SQL 静态检查，不代表真实 Supabase 已上线。

## 4. 随机抽名 10,000 次统计

固定种子 `mulberry32`；60 人中排除 1 人，对其余 59 人分别抽样 10,000 次。

| 模式 | 覆盖率 | 最少 | 最多 | 均值 | 变异系数 | 排除者 |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| 纯随机 | 100% | 141 | 207 | 169.49 | 0.0733 | 0 |
| 加权随机 | 100% | 153 | 187 | 169.49 | 0.0412 | 0 |

断言只要求全覆盖、排除者为 0 和宽松离散上限，避免苛刻概率断言导致偶发失败。主系统与独立页都确认默认选择“纯随机”。

## 5. 最终浏览器验收

| 场景 | 结果 | 证据 |
| --- | --- | --- |
| 未配置本地模式 | 打开即进入总览，无密码页；6班/360人/2课程/13考勤/3预警可载入 | `v12-local-360-dashboard.png`、`v125-final-dashboard.png` |
| 教师账号登录门 | 严格假服务下只允许管理员预建账号登录，不开放注册 | `v125-final-login.png` |
| 首次迁移/冲突 | 本机和云端摘要、分别导出、两种明确选择、二次确认可见 | `v12-first-migration-choice.png`、`v125-final-conflict.png` |
| 归档考勤 | 打开归档记录后保存、一键全勤和状态控件不可写 | `archived-attendance-readonly.png`、`v125-final-attendance.png` |
| 平时分 | 个性化项、权重、初始分和考勤自动计分可见 | `v125-final-scores.png` |
| 报表 | 桌面实际打开，Excel/PDF/打印存在；DOM 与报表字段不含合并出勤指标 | `v125-final-reports.png` |
| 错误备份 | 上传失败后原 720 人快照不变；页面明确说明未替换 | `invalid-backup-preserved.png`、`v125-final-backup.png` |
| 375px 手机 | 根页面无横向溢出；导航可展开；可见关键按钮均不低于 48px | `v125-final-mobile.png`、`v125-final-mobile-nav.png`、`v125-final-conflict-mobile.png` |
| 独立抽名页 | 单页无外链；既有 `file://` 实测完成粘贴/Excel/排除/抽名/清空；v1.2.5 HTTP 目检默认纯随机与最终样式 | `standalone-file-draw.png`、`v125-final-standalone.png` |
| PWA 离线/升级 | 同一 Chrome 资料由旧缓存更新为探针缓存且旧缓存删除；断网重载后标题、总览和 SW 控制均保持 | `v125-pwa-upgrade-before.png`、`v125-pwa-upgrade-after.png`、`v125-pwa-upgrade-offline.png` |

PWA DevTools Protocol 实际返回的核心状态：升级后缓存仅 `workbuddy-classroom-v1.2.5-upgrade-probe`，活动 worker 为 `activated`、无 waiting worker；离线重载后页面标题“教师课堂管理系统”、主标题“总览”、`controlled=true`。随后已删除探针并重新构建正式 `workbuddy-classroom-v1.2.5` 产物。

## 6. 静态边界检查

- 独立单页不含 Supabase SDK、URL、key 或网络请求；只在用户选文件时与主系统发生显式 JSON 桥接。
- Service Worker 对 `.supabase.co` 和 Auth/REST/Realtime/Storage/Functions 路径直接绕过，不缓存响应。
- 项目没有 Worker、D1、Drizzle、ChatGPT Auth、服务端认证或业务 API 运行/构建/测试依赖。
- 前端只接受 `VITE_SUPABASE_URL` 和 `VITE_SUPABASE_PUBLISHABLE_KEY`；仓库没有真实 secret、token、`.env` 或 `service_role` 值。
- 项目源码不使用 `eval()`。

## 7. 尚未验证/限制

- 没有真实 Supabase/Cloudflare 凭据，本轮未验证真实 Auth、RLS 跨账号隔离、Realtime 时延、免费项目休眠、Cloudflare HTTPS 回滚和两台真实设备同步。
- iPhone/iPad 最终 PWA 安装和 Safari 后台恢复必须在真实 HTTPS 部署后执行。
- PDF 为图像型，中文外观稳定但文字不可检索；真实打印机页边距仍取决于驱动。
- Supabase Free 无生产 SLA，云同步不能替代每周 JSON 备份。

完整条目映射见 `V1_2_5_COVERAGE.md` 和 `REQUIREMENTS_MAPPING.md`。
