import { mkdir, writeFile } from "node:fs/promises";
import { createFictionalDataset, exportDatabase, validateDatabase } from "../src/core.mjs";

const dataset = createFictionalDataset();
validateDatabase(dataset);
await mkdir(new URL("../tests/fixtures/", import.meta.url), { recursive: true });
await writeFile(new URL("../tests/fixtures/v11-fictional-dataset.json", import.meta.url), exportDatabase(dataset), "utf8");
console.log("虚构数据集：2学期、6班、每学期每班60人、2门课程；已校验");
