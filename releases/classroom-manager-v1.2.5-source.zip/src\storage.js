import { createEmptyData, migrateScoreConfiguration, validateDatabase } from "./core.mjs";

const DATA_KEY = "workbuddy.classroom.v1.1.data";

export function loadData() {
  try {
    localStorage.removeItem("workbuddy.classroom.v1.1.lock");
    localStorage.removeItem("workbuddy.classroom.v1.1.session");
    const raw = localStorage.getItem(DATA_KEY);
    return raw ? validateDatabase(migrateScoreConfiguration(JSON.parse(raw))) : createEmptyData();
  } catch {
    return createEmptyData();
  }
}

export function saveData(data) {
  validateDatabase(data);
  localStorage.setItem(DATA_KEY, JSON.stringify(data));
}

export function replaceDataAtomically(data) {
  const validated = validateDatabase(data);
  const temporaryKey = `${DATA_KEY}.pending`;
  localStorage.setItem(temporaryKey, JSON.stringify(validated));
  const reread = validateDatabase(JSON.parse(localStorage.getItem(temporaryKey)));
  localStorage.setItem(DATA_KEY, JSON.stringify(reread));
  localStorage.removeItem(temporaryKey);
}
